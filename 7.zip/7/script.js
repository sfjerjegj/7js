{
    "students" [
      { "id": 1, "name": "Beka", "age": 14 },
      { "id": 2, "name": "Maks", "age": 16 }
    ]
  }
  